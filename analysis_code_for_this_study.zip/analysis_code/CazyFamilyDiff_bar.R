#####rep 1 有重复#####
library(dplyr)
library(readxl)
library(ggpubr)
library(ggbreak)
args <- commandArgs(T)
data <- args[1]
outdir <- args[2]
title <- args[3]
setwd(outdir)
df <- read.delim(data,check.names =F,sep = "\t")
df
library(tidyr)
df %>% 
  pivot_longer(!group) -> new_df
new_df
ebtop<-function(x){
  return(mean(x)+sd(x)/sqrt(length(x)))
}
ebbottom<-function(x){
  return(mean(x)-sd(x)/sqrt(length(x)))
}
library(ggplot2)
name_lst <- unique(new_df$name) #tdl
#new_df$name <- factor(new_df$name, levels = name_lst)  #tdl
 p = ggplot(data=new_df,aes(x=name,y=value,fill=group))+
   geom_bar(stat="summary",fun="mean",
            position=position_dodge(0.9),
            width=0.8) + 
   stat_summary(geom = "errorbar",
               fun.min = ebbottom,
               fun.max = ebtop,
               position = position_dodge(0.9),
               width=0.2)+
#   stat_compare_means(aes(group=name),method = "t.test",label="p.format", position="jitter")+  #tdl
#   stat_compare_means(aes(group=name), label="p.format", method = "t.test", label.x.npc = 0.6, label.y.npc=0.6)+
   stat_compare_means(method="wilcox.test", label="p.signif",label.y=160)+
#   stat_compare_means(method = "wilcox.test",label="p.signif")+  #tdl
   #scale_fill_manual(values = c("C"="#050F4B","A"="#5699C1"))+ ##ylj
   theme_classic()+
   theme(panel.grid = element_blank(),plot.title = element_text( hjust = 0.5),axis.text.x = element_text(angle = 70,vjust = 0.85,hjust = 0.75))+
   labs(title=title,hjust=0.5,x="",y="Counts of MAGs",fill="")
p1 = p+
#scale_y_continuous(limits = c(0, 190),breaks = c(0,1,2,3,4,4.5),label = c("0","1","2","3","4","4.5"))+
   scale_y_break(c(6,8),scales =0.5,ticklabels=c(8,50,100,150,200),expand=expansion(add = c(0,0)))

 pdf(paste0(title,".bar.pdf"),width=6,height=4,onefile = FALSE)
 p1
 dev.off()
 png(paste0(title,".bar.png") ,type = "cairo-png", width = 480*5, height = 480*3, res = 72*4)
 p1
 dev.off()
