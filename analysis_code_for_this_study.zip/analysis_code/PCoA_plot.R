library(ggplot2)
library(vegan)
library(ggforce)
groups = read.table("group.xls", sep="\t",header=T,colClasses=c("character","character"),na.strings=T,check.names=F)
sample_site<-read.table("PCoA.csv",sep=",",header=T,check.names=F)
colnames(sample_site)<-c('sample','PC1','PC2')
sample_site<-merge(sample_site,groups,by.x="sample",by.y = "sample")
PC = read.table("PC.txt",sep="\t",header=T,check.names=F,row.names=1)
pc1= PC[1,]
pc2= PC[2,]

p<-ggplot(sample_site,aes(x=PC1,y=PC2,col=group))+
  geom_point()+
  labs(title="PCoA Plot") + xlab(paste("PC1(",pc1,"%",")",sep="")) + ylab(paste("PC2(",pc2,"%",")",sep=""))+
  theme(text=element_text(family="Arial",size=6))+
  geom_vline(aes(x=0,y=0),xintercept=0,linetype="dotted")+
  geom_hline(aes(x=0,y=0),yintercept=0,linetype="dotted")+
  #geom_mark_ellipse(aes(fill=group),
  #                  alpha=0.2,
  #                  position="identity")+
#  stat_ellipse(level=0.95,aes(fill=group),
#               alpha=0.2,geom="polygon",linetype=1)+ #置信阈值，值越大包含的点越多
#  scale_color_manual(values = c("Healthy"="#4874CB","OB"="#FEDB61","SG_pre"="#9EC1BA","SG_1M"="#9AE7DF","SG_3M"="#30C0B4","LSG_pre"="#F6B281","LSG_6M"="#EE822F","RYGB_pre"="#BE90A8","RYGB_1M"="#F4B7BE","RYGB_3M"="#EE7E8E","RYGB_6M"="#E22C4A","RYGB_12M"="#A3172E"))+
#  scale_fill_manual(values = c("Healthy"="#4874CB","OB"="#FEDB61","SG_pre"="#9EC1BA","SG_1M"="#9AE7DF","SG_3M"="#30C0B4","LSG_pre"="#F6B281","LSG_6M"="#EE822F","RYGB_pre"="#BE90A8","RYGB_1M"="#F4B7BE","RYGB_3M"="#EE7E8E","RYGB_6M"="#E22C4A","RYGB_12M"="#A3172E"))+
  #stat_ellipse(level=0.9)+ #可绘制两个置信圈
  #theme_bw()+
  theme_classic()+
  #scale_fill_manual(values=c("grey33","red","green","blue"))+
  #scale_color_manual(values=c("grey33","red","green","blue"))+
  theme(plot.margin = margin(10,10,10,20),legend.background = element_blank())
ggsave(paste("PCoA_project.png", sep=""), p, width = 6, height = 5)
ggsave(paste("PCoA_project.pdf", sep=""), p, width = 6, height = 5)
