library("tidyverse")
library("ape")
library("stringr")
library("ggtree")
library("ggplot2")

# 设置文件路径（请根据你的具体文件调整这些路径）
disfile <- "combined_distance.tsv"       # 输入距离数据文件路径
outmat <- "ned_distance_mat.txt"           # 距离矩阵输出文件路径
outviz <- "tree.pdf"             # 系统发育树可视化PDF文件路径

# 读取距离数据
datdis <- read.table(disfile, header=FALSE, stringsAsFactors=FALSE)
colnames(datdis) <- c("anim1", "anim2", "distr", "comp4", "comp5")

# 转换距离数据为宽格式矩阵
datsel <- datdis %>% select(anim1, anim2, distr)
datwide <- datsel %>% pivot_wider(names_from = anim2, values_from = distr)
datmat <- as.matrix(datwide %>% select(-anim1))
rownames(datmat) <- datwide$anim1

# 写入距离矩阵到文件
write.table(datmat, file=outmat, sep="\t", quote = FALSE)
# 检查并选择外群
ref <- "SampleRef" # 这需要替换为实际的参考名称
if(ref %in% rownames(datmat)) {
  outgroup <- which.max(datmat[ref,]) %>% names()
} else {
  print("Reference not found in the matrix row names.")
}

# 应用邻接法构建系统发育树
tr <- nj(datmat)
nwkfile <- "tree.nwk" # 系统发育树的Newick格式文件输出路径
write.tree(tr, file=nwkfile) # 保存系统发育树为Newick格式

#ggtree
#new.tr<-root(tr,outgroup = "An")
# 可视化系统发育树
pdf(outviz, width=15, height=14)
#plot.phylo(tr, cex=2, edge.width=2) # 如果没有指定外群，则仅绘制树
#if(exists("ref")) {
#  plot.phylo(root(tr, outgroup=outgroup), cex=1, edge.width=2)
#}
#axisPhylo(backward=FALSE, cex.axis=2)
ggtree(tr,layout = "circular", branch.length = "none", size = 0.3) +
  geom_tiplab(color = "grey50", hjust = -0.1, size = 0.3, offset = 0.5)
dev.off()

### 子进化树

# 指定您希望保留的物种名称列表
species_to_keep <- c("ERR1190612.bin.22","ERR1190612.bin.29","ERR1190731.bin.21","ERR1190736.bin.12","ERR1190758.bin.25","ERR1305885.bin.2","SRR12803063.bin.22","SRR12803064.bin.9","SRR12803127.bin.37","ERR1190534.bin.11","ERR1190536.bin.14","ERR1190537.bin.14","ERR1190538.bin.7","ERR1190545.bin.6","ERR1190546.bin.20","ERR1190547.bin.20","ERR1190551.bin.5","ERR1190553.bin.4","ERR1190555.bin.16","ERR1190556.bin.12","ERR1190557.bin.3","ERR1190559.bin.25","ERR1190564.bin.18","ERR1190564.bin.3","ERR1190565.bin.33","ERR1190573.bin.7","ERR1190576.bin.15","ERR1190577.bin.6","ERR1190580.bin.16","ERR1190581.bin.33","ERR1190582.bin.12","ERR1190586.bin.1","ERR1190593.bin.22","ERR1190599.bin.20","ERR1190607.bin.22","ERR1190615.bin.7","ERR1190616.bin.15","ERR1190616.bin.36","ERR1190617.bin.3","ERR1190617.bin.8","ERR1190620.bin.25","ERR1190621.bin.3","ERR1190623.bin.13","ERR1190623.bin.18","ERR1190634.bin.10","ERR1190637.bin.19","ERR1190640.bin.5","ERR1190644.bin.1","ERR1190645.bin.10","ERR1190645.bin.6","ERR1190647.bin.18","ERR1190647.bin.24","ERR1190650.bin.15","ERR1190650.bin.38","ERR1190656.bin.24","ERR1190657.bin.1","ERR1190657.bin.8","ERR1190658.bin.39","ERR1190659.bin.8","ERR1190664.bin.3","ERR1190665.bin.16","ERR1190666.bin.5","ERR1190667.bin.25","ERR1190670.bin.19","ERR1190670.bin.27","ERR1190671.bin.11","ERR1190672.bin.8","ERR1190675.bin.18","ERR1190676.bin.20","ERR1190677.bin.13","ERR1190678.bin.11","ERR1190679.bin.12","ERR1190686.bin.10","ERR1190689.bin.3","ERR1190692.bin.9","ERR1190698.bin.28","ERR1190699.bin.17","ERR1190700.bin.15","ERR1190701.bin.30","ERR1190702.bin.29","ERR1190705.bin.6","ERR1190706.bin.3","ERR1190707.bin.24","ERR1190707.bin.36","ERR1190709.bin.11","ERR1190709.bin.14","ERR1190709.bin.6","ERR1190715.bin.6","ERR1190719.bin.19","ERR1190719.bin.21","ERR1190725.bin.10","ERR1190727.bin.2","ERR1190728.bin.17","ERR1190730.bin.6","ERR1190732.bin.6","ERR1190733.bin.2","ERR1190736.bin.26","ERR1190737.bin.12","ERR1190739.bin.20","ERR1190741.bin.17","ERR1190743.bin.8","ERR1190745.bin.5","ERR1190745.bin.7","ERR1190751.bin.21","ERR1190753.bin.16","ERR1190755.bin.2","ERR1190761.bin.2","ERR1190762.bin.13","ERR1190770.bin.10","ERR1190772.bin.24","ERR1190774.bin.15","ERR1190775.bin.7","ERR1190778.bin.12","ERR1190780.bin.10","ERR1190781.bin.14","ERR1190783.bin.18","ERR1190785.bin.16","ERR1190786.bin.19","ERR1305877.bin.42","ERR1305877.bin.64","ERR1305878.bin.15","ERR1305879.bin.10","ERR1305880.bin.9","ERR1305883.bin.31","ERR1305887.bin.25","ERR1305887.bin.37","ERR1305888.bin.3","ERR1305890.bin.7","ERR1305894.bin.26","ERR1305894.bin.50","ERR1305897.bin.26","ERR1305903.bin.28","ERR1305904.bin.12","ERR1305905.bin.11","ERR1305905.bin.23","SRR10901873.bin.22","SRR10901881.bin.4","SRR10901884.bin.25","SRR10901885.bin.19","SRR10901885.bin.3","SRR10901888.bin.13","SRR10901895.bin.8","SRR10901899.bin.26","SRR10901900.bin.14","SRR10901903.bin.21","SRR10901905.bin.6","SRR10901910.bin.24","SRR10901918.bin.19","SRR10901926.bin.2","SRR10901933.bin.3","SRR10901946.bin.26","SRR12803055.bin.3","SRR12803060.bin.16","SRR12803061.bin.29","SRR12803073.bin.26","SRR12803078.bin.27","SRR12803087.bin.11","SRR12803087.bin.5","SRR12803094.bin.3","SRR12803097.bin.10","SRR12803098.bin.4","SRR12803108.bin.21","SRR12803111.bin.4","SRR12803115.bin.17","SRR12803118.bin.15","SRR12803119.bin.36","SRR12803119.bin.41","SRR12803136.bin.33","SRR12803152.bin.12","SRR12803154.bin.25","SRR12803171.bin.10","SRR12803171.bin.53","SRR12803150.bin.14","ERR1305899.bin.2","SRR12803040.bin.36","SRR12803102.bin.17","SRR12803155.bin.23","ERR1190593.bin.25","ERR1190600.bin.22","ERR1190609.bin.18","ERR1190706.bin.5","ERR1190747.bin.11","ERR1305885.bin.36","SRR10901944.bin.2","SRR12803045.bin.14","SRR12803090.bin.14","SRR12803124.bin.32","SRR12803146.bin.1","SRR12803157.bin.52","SRR12803159.bin.3","SRR12803161.bin.16")

# 确保物种名称与树中的标签匹配
# 如果树中的物种名称不是这些精确字符串，您需要先将它们对应起来
# 指定 Newick 文件的路径
#nwk_file_path <- "newtree.nwk.txt"
# 读取 Newick 文件
#tr <- read.tree(file = nwk_file_path)

# 从完整的系统发育树中保留特定的物种
tr_sub <- keep.tip(tr, species_to_keep)

# 指定新 Newick 文件的保存路径
nwk_file_path <- "subset_tree_addOB.nwk"

# 保存新的树为 Newick 格式
write.tree(tr_sub, file=nwk_file_path)
#pdf("sub_tree.pdf", width=15, height=14)
#ggtree(tr_sub,layout = "circular", branch.length = "none", size = 1) +
#  geom_tiplab(color = "grey50", hjust = -0.1, size = 2, offset = 0.5)
#dev.off()

