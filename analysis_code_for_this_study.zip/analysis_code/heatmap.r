library(pheatmap)
x<-read.table("estimate.out.tax.xls",sep="\t",header=T,row.names=1)
group<-read.table("group.xls",sep="\t",header=F)
group2<-read.table("tax.group",sep="\t",header=F)
annotation_col = data.frame(Group=factor(group$V4),Group2=factor(group$V5),
                            Dataset=factor(group$V3),Position=factor(group$V2))
annotation_row = data.frame(TaxType=factor(group2$V2))
rownames(annotation_col) = group$V1
rownames(annotation_row) = group2$V1

ann_colors=list(Dataset=c("PRJEB12123"="#F8766D","PRJEB12947"="#7CAE00","PRJNA597839"="#00BFC4","PRJNA668357"="#C77CFF"),
                Group=c("Healthy"="#4874CB","LSG"="#EE822F","OB"="#FEDB61","RYGB"="#C00000","SG"="#588E31"),
                Group2=c("Healthy"="#4874CB","OB"="#FEDB61","Treat"="#BE90A8"),
                Position=c("China"="red","Denmark"="blue",USA="#32CD32"),
                TaxType=c("Non-probiotic"="#FFBB7F","Probiotic"="#5050FF"))

#png("heatmap_high_res_change.png", width = 2400, height = 1600, res = 300)  # 设置宽度、高度和分辨率
pdf("heatmap_high_res_change.pdf",width =12,height=7)
pheatmap(x,scale="row",cluster_cols=F,cluster_rows=T,
            display_numbers =F, angle_col = "45",
            annotation_col=annotation_col,annotation_colors=ann_colors,
            color = colorRampPalette(c("#00A087B2","#91D9C2B2","white","#F39B7FB2","#E64B35B2"))(60),
            show_colnames=FALSE,show_rownames=T,cellheight=12,fontsize=10,
            annotation_row=annotation_row,gaps_row=c(1),
            cellwidth=0.9,legend=T) 
dev.off()  # 关闭PDF设备


