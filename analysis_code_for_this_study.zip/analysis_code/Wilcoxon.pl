#!usr/bin/perl -w
use strict;
use Cwd qw(abs_path);# 获取当前操作目录

my ($table,$group,$outdir)=@ARGV; # 定义输入、输出变量存到数组
@ARGV || die "perl $0 <table，行为样本，列为特征> <group> <outdir>\n"; # 定义调用命令
-d $outdir || mkdir $outdir; # 设置该变量名为输出文件名，-d判断 是否存在该文件夹，存在则直接作为输出目录，不存在则生成一个目录
$outdir=abs_path($outdir); 
#-------------------
my %group;
my %groupname;
open IN,$group; #分组信息读取
while(<IN>){
	chomp; # 删除每行末尾的换行符
	my @or=split /\t/;  # 定义该数组以\t为分隔符对每行进行切割
	$group{$or[0]}=$or[1]; # 以哈希形式保存 样本:分组数据
	$groupname{$or[1]}=1;  # 以哈希形式保存 分组，用于后续的去重
}
close IN;
my $group_vs=vs(\%groupname); # 对存有组名的哈希调用vs子函数对组名去重
my @group_vs_array = split(',', $group_vs);

#---------------------
open IN,$table; # 绘图数据读取,行名为样本名，列名为特征
open OUT,">$outdir/Wilcoxon.test.input.xls"; # 生成R绘图所需的文件名
## 整理R绘图所需输入文件格式，整理为样本列+分组列+物种名的矩阵
my $title=<IN>;chomp $title; # 读取第一行标题，即特征名
my @tarr=split /\t/,$title;  # 切割标题
print OUT "tax\t","group_name\t",join("\t",@tarr[1..$#tarr]),"\n"; # 重新设置列名,即标题
while(<IN>){
	chomp;
	my @or=split /\t/;
	if($group{$or[0]}){
		print OUT $or[0],"\t",$group{$or[0]},"\t",join("\t",@or[1..$#or]),"\n"; #判断or和tarr中的样本名是否可匹配，True则输出样本名+组名+后面特征的值
	}else{
		print STDERR "$or[0] 未识别到分组信息\n";
		next;
	}
}
close IN;
close OUT;


	## 打印R脚本  ##
my $file =<< "EOF";

#分组按照列名
#输入数据为一个样本列+分组列+物种名的列表
file<-"Wilcoxon.test.input.xls"
df <- read.table(file,header = T,sep="\\t",row.names = 1,check.names = F)
group <- df\$group_name
P_value <- NULL
G1_mean <- NULL
G2_mean <- NULL
log2FC <-NULL
for (i in 2:ncol(df)){
  x <-subset(df,group == $group_vs_array[0],select = i)
  y <-subset(df,group == $group_vs_array[1],select = i)
  test <- wilcox.test(as.numeric(t(x)),as.numeric(t(y)),alternative = 'two.sided')
  #提取P值
  P_value <-c(P_value, test\$p.value)
  #计算各组均值和比值
  G1_mean <- c(G1_mean,mean(as.numeric(t(x))))
  G2_mean <- c(G2_mean,mean(as.numeric(t(y))))
  log2FC <- c(log2FC,log(mean(as.numeric(t(x)))/mean(as.numeric(t(y))),2))
}
#将原数据表转置为物种为行名的格式，以便P值可以按列合并
pre_out <-t(df[,-1])
tax <- rownames(pre_out)
out<- cbind(tax,pre_out,G1_mean,G2_mean,log2FC,P_value)
write.table(out,file='wilcoxon-result.xls',quote=F,sep='\\t',row.names=F)

EOF

#输出R脚本
open OUT,">$outdir/Wilcoxon.test.R";
print OUT $file;
close OUT;

#调用R，运行画图脚本
system "cd $outdir;/data/Tools/Software/miniconda3/install/bin/R -f Wilcoxon.test.R";

sub vs {
	my $tmp=shift;
	my %hash=%{$tmp};
	my @name=sort keys %hash;
	
	my @arr;
	foreach my $i (0..$#name-1){
		foreach my $j ($i+1..$#name){
			push @arr,"\"$name[$i]\",\"$name[$j]\"";
		}
	}
	my $vsname=join(",",@arr);
	return $vsname;
}
