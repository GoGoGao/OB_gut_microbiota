library(ggplot2)
library(ggpubr)
library(patchwork)
library(dplyr)
file<-"ggpubr.box.input.table.xls"
dataset <- read.table(file,header = T,sep="\t")

#优化-去掉未检出值批量箱型图
dataset[dataset == 0] <-NA

for (i in 2:length(colnames(dataset))){
  #循环提取除行标题的每一列，并合并为两列的数据框
  df <- dataset[c(1,i)]
  #去掉未检出的样本
  df1 <-na.omit(df)
  my_comparisons <- list(c("OB","RYGB_12M"),c("OB","RYGB_1M"),c("OB","RYGB_6M"),
                         c("RYGB_12M","RYGB_1M"),c("RYGB_12M","RYGB_6M"),c("RYGB_1M","RYGB_12M"),
                         c("RYGB_1M","RYGB_6M"))
  m = as.numeric(max(df1[,2]))
  v1 = 1.05*m
v2 = 1.14*m
v3 = 1.23*m
v4 = 1.32*m
v5 = 1.41*m
v6 = 1.50*m
v7 = 1.59*m
v8 = 1.68*m
v9 = 1.77*m

  p<- ggboxplot(df1, 
                x = "group_name", 
                y = colnames(dataset)[i],      
                color = "group_name", 
                #palette = "npg" ,#两两比较的p值
                palette = c("OB"="#FEDB61","RYGB_1M"="#C00000","RYGB_6M"="#C00000","RYGB_12M"="#C00000"),
                add = "jitter",#添加图形元素
                add.params = list(size = 2, alpha = 1),
				shape = "group_name"
  )+stat_compare_means(comparisons = my_comparisons,
                       label.y = c(v1,v2,v3,v4,v5,v6,v7,v8,v9)
  )+stat_compare_means(label.y = 1.86*m)+
    labs(x="")
  ggsave(p,file=paste(colnames(dataset)[i],".png",sep=""),width = 6,height = 6,limitsize = F)
  ggsave(p,file=paste(colnames(dataset)[i],".pdf",sep=""),width = 6,height = 6,limitsize = F)
  write.table(df1,paste(colnames(dataset)[i],"filter.draw.input.xls",sep = ""),sep="	")
}

