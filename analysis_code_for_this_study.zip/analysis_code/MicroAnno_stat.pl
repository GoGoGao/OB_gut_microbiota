#!usr/bin/perl -w
use strict;

my (%SamID,%ha2,%py,%count,%countpy,$p);
open IN,$ARGV[0];
while(<IN>){
	chomp;
	/^user_genome/ && next;
	my @ll=split /\t/;
	my @aa=split /\./,$ll[0];
	$SamID{$aa[0]}+=1;
	$p=(split ";",$ll[1])[1];
	$ha2{$aa[0]}{$p}+=1;  
	$py{$p}=1;
}
close IN;

open IN,$ARGV[1];
while(<IN>){
	chomp;
	my @ll=split /\t/;
	if($SamID{$ll[0]}){
		my $str="$ll[1]\t$ll[2]\t$ll[3]";
		$count{$str}+=$SamID{$ll[0]};
		foreach(keys %py){
                        $ha2{$ll[0]}{$_} ||=0;
                        #print STDERR "$num\n";
			$countpy{$str}{$_}+=$ha2{$ll[0]}{$_};
		}
	}else{
		next;
	}
}
close IN; 

print "project\tsite\tgroup\tMAGs_num";
for my $j(sort keys %py){
	print "\t$j";
}
print "\n";

for my $i(keys %count){
	print "$i\t$count{$i}";
	for my $k(sort keys %py){
		$countpy{$i}{$k} ||=0;
		print "\t$countpy{$i}{$k}";
	}
	print "\n";
}
