library(vegan)
library(permute)
library(lattice)
#otu <- read.table("/data/Work/lj/project/zhifang/03.analyse/03.diff_duilie/absolute.s.xls",comment.char = "", header = T, row.names = 1,sep = "\t")
otu <- read.table("input.xls",comment.char = "", header = T, row.names = 1,sep = "\t")
otu<-t(otu)
group<-read.table("group.txt",sep="\t",header = T, row.names = 1)

#队列影响情况
adonis2(formula = otu ~ group$project, data = group, permutations = 999, distance = "bray")
anosim(x = otu, grouping = group$project, permutations = 999) 
#粗略分组影响情况
adonis2(formula = otu ~ group$Group3, data = group, permutations = 999, distance = "bray")
anosim(x = otu, grouping = group$Group3, permutations = 999)
#粗略分组影响情况2,OB-Healthy-Treat
adonis2(formula = otu ~ group$Group4, data = group, permutations = 999, distance = "bray")
anosim(x = otu, grouping = group$Group4, permutations = 999)
#细致分组影响情况
adonis2(formula = otu ~ group$Group1, data = group, permutations = 999, distance = "bray")
anosim(x = otu, grouping = group$Group1, permutations = 999)
#国家位置影响情况
adonis2(formula = otu ~ group$site, data = group, permutations = 999, distance = "bray")
anosim(x = otu, grouping = group$site, permutations = 999)
