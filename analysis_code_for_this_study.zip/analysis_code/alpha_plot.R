##################### alpha 多样性 ########################
library("ggpubr")
library(ggplot2)
data<-read.delim("alpha_res.txt",sep ="\t",header = T,check.names = F)
p<-ggboxplot(data, "Time","shannon", 
             color = "Type",size = 1,shape = "Project",
             #notch = F,
             add = "jitter",
             add.params = list(size = 2, alpha = 1),
             outlier.shape = 19,
             palette = c("Healthy"="#4874CB","LSG"="#EE822F","OB"="#FEDB61","RYGB"="#C00000","SG"="#588E31"),
             legend = "right")+
  labs(x=" ",y="ace",fill="")+
  theme(text=element_text(size =16))+
  theme(axis.text.x = element_text(angle=45,hjust = 0.5,vjust = 0.5,size =14,color="black"),
        axis.text.y= element_text(hjust=1,size=14,color="black"))+
  theme(legend.title = element_blank())
ggsave(p,file=paste("boxplot_alpha_shannon",".png",sep=""),width = 14,height = 5,limitsize =F )
ggsave(p,file=paste("boxplot_alpha_shannon",".pdf",sep=""),width = 14,height = 5,limitsize =F )

p<-ggboxplot(data, "Time","ace", 
          color = "Type",size = 1,
          #notch = F,
          add = "jitter",
          add.params = list(size = 2, alpha = 1),
          outlier.shape = 19,
          palette = c("Healthy"="#4874CB","LSG"="#EE822F","OB"="#FEDB61","RYGB"="#C00000","SG"="#588E31"),
          legend = "right")+
  labs(x=" ",y="ace",fill="")+
  theme(text=element_text(size =16))+
  theme(axis.text.x = element_text(angle=45,hjust = 0.5,vjust = 0.5,size =14,color="black"),
        axis.text.y= element_text(hjust=1,size=14,color="black"))+
  theme(legend.title = element_blank())
ggsave(p,file=paste("boxplot_alpha_ace",".png",sep=""),width = 7,height = 5,limitsize =F )
ggsave(p,file=paste("boxplot_alpha_ace",".pdf",sep=""),width = 7,height = 5,limitsize =F )

#健康组的两个队列多样性的+pvalue
df_h<-data[data$Type == "Healthy",]
my_comparisons <- list(c("PRJEB12123","PRJNA597839"))
m = as.numeric(max(df_h$shannon))
p<-ggboxplot(df_h, "Project","shannon", 
             color = "#4874CB",
             size = 1,shape = "Project",
             add = "jitter",
             add.params = list(size = 2, alpha = 1),
             outlier.shape = 19,
             #palette = c("Healthy"="#4874CB","LSG"="#EE822F","OB"="#FEDB61","RYGB"="#C00000","SG"="#588E31"),
             legend = "right")+
  stat_compare_means(comparisons = my_comparisons,label.y = 1.2*m)+
  labs(x=" ",y="shannon",fill="")+
  theme(text=element_text(size =16))+
  theme(axis.text.x = element_text(angle=45,hjust = 0.5,vjust = 0.5,size =14,color="black"),
        axis.text.y= element_text(hjust=1,size=14,color="black"))+
  theme(legend.title = element_blank())
ggsave(p,file=paste("boxplot_alpha_shannon_Healthy",".png",sep=""),width = 6,height = 5,limitsize =F )
ggsave(p,file=paste("boxplot_alpha_shannon_Healthy",".pdf",sep=""),width = 6,height = 5,limitsize =F )


#肥胖组的两个队列多样性的+pvalue
df_OB<-data[data$Type == "OB",]
my_comparisons <- list(c("PRJEB12123","PRJNA597839"),c("PRJEB12123","PRJNA668357"),
                       c("PRJEB12123","PRJEB12947"),c("PRJNA597839","PRJNA668357"),
                       c("PRJNA597839","PRJEB12947"),c("PRJNA668357","PRJEB12947"))
m = as.numeric(max(df_OB$ace))
v1 = 1.08*m
v2 = 1.16*m
v3 = 1.24*m
v4 = 1.32*m
v5 = 1.4*m
v6 = 1.48*m
p<-ggboxplot(df_OB, "Project","ace", 
             color = "#FEDB61",
             size = 1,shape = "Project",
             add = "jitter",
             add.params = list(size = 2, alpha = 1),
             outlier.shape = 19,
             #palette = c("Healthy"="#4874CB","LSG"="#EE822F","OB"="#FEDB61","RYGB"="#C00000","SG"="#588E31"),
             legend = "right")+
  stat_compare_means(comparisons = my_comparisons,label.y = c(v1,v2,v3,v4,v5,v6))+
  stat_compare_means(aes(group=Project),label.y = 1.6*m)+
  labs(x=" ",y="ace",fill="")+
  theme(text=element_text(size =16))+
  theme(axis.text.x = element_text(angle=45,hjust = 0.5,vjust = 0.5,size =14,color="black"),
        axis.text.y= element_text(hjust=1,size=14,color="black"))+
  theme(legend.title = element_blank())
ggsave(p,file=paste("boxplot_alpha_ace_OB",".png",sep=""),width = 6,height = 5,limitsize =F )
ggsave(p,file=paste("boxplot_alpha_ace_OB",".pdf",sep=""),width = 6,height = 5,limitsize =F )
