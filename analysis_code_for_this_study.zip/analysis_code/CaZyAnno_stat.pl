#!usr/bin/perl -w
use strict;

my (%anno,%anno_des,%mark,%anno_spe,%mark_spe);

open IN,$ARGV[0];
while(<IN>){
    chomp;
    my @ll=split /\t/;
    $mark{$ll[0]}=1;
    $mark_spe{$ll[0]}=$ll[1];
}
close IN;

open IN,$ARGV[1];
while(<IN>){
    chomp;
    my @ll=split /\//;
    my $bins_id=(split ".cazy.",$ll[-1])[0];
    if($mark{$bins_id}){
        my $F;
        open $F,$_;
        while(<$F>){
            chomp;
            /^Gene_id/ && next;
            my @aa=split /\t/;
            $anno{$bins_id}{$aa[3]}=1;
            my $sp=$mark_spe{$bins_id};
            $anno_spe{$sp}{$aa[3]}++;
            $anno_des{$aa[3]}="$aa[4]\t$aa[5]\t$aa[6]";
        }
        close $F;
    }else{
        next;
    }
}
close IN;

open OUT,">cazy.description.xls";
print OUT "GenBank_ACCESSION\tCAZy_family\tFamily_known-activities\tFamily_note\n";
foreach(keys %anno_des){
    print OUT "$_\t$anno_des{$_}\n";
}
close OUT;

open OUT2,">bins_cazy_anno.xls";
open OUT3,">spe_cazy_anno.xls";
print OUT2 "bins";
print OUT3 "spe";
for my $d(sort keys %anno_des){
    print OUT2 "\t$d";
    print OUT3 "\t$d";
}
print OUT2 "\n";
print OUT3 "\n";

for my $b(keys %anno){
    print OUT2 "$b";
    for my $a(sort keys %anno_des){
        $anno{$b}{$a} ||=0;
        print OUT2 "\t$anno{$b}{$a}";
    }
    print OUT2 "\n";
}
close OUT2;

for my $s(keys %anno_spe){
    print OUT3 "$s";
    for my $a(sort keys %anno_des){
        $anno_spe{$s}{$a} ||=0;
        print OUT3 "\t$anno_spe{$s}{$a}";
    }
    print OUT3 "\n";
}
close OUT3;
