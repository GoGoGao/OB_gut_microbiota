library("tidyverse")
library(ggplot2)
data<-read.table("cazy_plot3.txt",fill=T,quote="",header = T,sep = "\t",check.names = F)
library(reshape2)
data2<-melt(data,id="type")
x=20
head(data2)
colnames(data2)<-c("type","variable","relative")
data2<-data2[order(data2$type),]
#data2$type<-factor(data2$type,levels =data2$type )
P <- ggplot(data2,aes(variable,type))+
  geom_point(aes(size=relative*10,color=relative))+
  scale_color_gradientn(colours=c("#00A087B2","white","#E64B35B2"))+
  labs(x='',y='CaZy Family')+
  #scale_size_continuous(breaks=round(seq(min(data2$value),max(data2$value),1),0))+
  guides( colour = guide_colourbar(order = 2),size = guide_legend(order = 1) )+
  theme_bw()+
  theme(panel.background = element_rect(fill = NA, color = 'black'),
        axis.text.x = element_text(angle = 60, hjust = 1, vjust = 1,size = 14),
        axis.text.y = element_text(size = 14),
        plot.title=element_text(hjust = 0.5))
P
ggsave("CaZy.scatterplot.18spe.pdf",P,height = 13,width = 8)
ggsave("CaZy.scatterplot.18spe.png",P,height = 13,width = 8)
